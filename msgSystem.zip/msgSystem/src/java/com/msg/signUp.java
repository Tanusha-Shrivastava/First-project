
package com.msg;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 public class signUp extends HttpServlet {   
    
    @Override
        public void doPost(HttpServletRequest request, HttpServletResponse response){
        try{
            
        String name=request.getParameter("sname");
        String pass=request.getParameter("pass");
           
        boolean i=false;
            SignupDao obj=new SignupDao();
            
            try{
                i=obj.putValue(name,pass);              
            }catch(Exception e){}
            
            if(i){response.sendRedirect("login.jsp");}
            else {response.sendRedirect("signupPage.jsp");}
        
        }catch(Exception e){}
    }

}
