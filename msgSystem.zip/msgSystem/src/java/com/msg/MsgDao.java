package com.msg;

import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MsgDao {
    
    public int sendMsg(String sname,String rname,String msg) throws ClassNotFoundException, SQLException{
        
        String query="insert into msgbox values(?,?,?,?)";
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/msg","root","s6h5i4v3a2m1");
        PreparedStatement pr=con.prepareStatement(query);
        
        Date date=new Date();
        long time=date.getTime();
        pr.setString(1,sname);
        pr.setString(2,rname);
        pr.setLong(3,time);
        pr.setString(4,msg);
        
        int count=pr.executeUpdate();
        
        return count;
    }
    
    public String getMsg(String sname,String rname) throws ClassNotFoundException,SQLException {
        String query="select * from msgbox where (sname=? and rname=?) or (sname=? and rname=?)";
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/msg","root","s6h5i4v3a2m1");
        PreparedStatement pr=con.prepareStatement(query);
        
        pr.setString(1,sname);
        pr.setString(2,rname);
        pr.setString(3,rname);
        pr.setString(4,sname);
        
        ResultSet rs=pr.executeQuery();
        String fullmsg="";
        
        while(rs.next()){
            long d=rs.getLong("time");
            Date date=new Date(d);
            
            if(rs.getString("sname").equals(sname))
                fullmsg+="You   :   "+rs.getString("msg")+"<br/>Time    :   "+date+"<br/><br/>";
            else{
                fullmsg+=rname+"   :   "+rs.getString("msg")+"<br/>Time    :   "+date+"<br/><br/>";
            }
        }
        return fullmsg;
    }
}
