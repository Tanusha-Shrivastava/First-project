package com.msg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDao {
    
    String query="select * from login_info where name=? and pass=?";
    public boolean check(String sname,String pass) throws ClassNotFoundException, SQLException{
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/msg","root","s6h5i4v3a2m1");
        PreparedStatement pr=con.prepareStatement(query);
        pr.setString(1,sname);
        pr.setString(2,pass);
        ResultSet rs=pr.executeQuery();
               
        if(rs.next()){            
            return true;
        }
        return false;
    }
}
