package com.msg;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class loginCheck extends HttpServlet {   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
        String sname=request.getParameter("sname");
        String pass=request.getParameter("pass");
        
        LoginDao obj=new LoginDao();
        
        try {
           
            if(obj.check(sname,pass)){
                
                HttpSession session=request.getSession();
                session.setAttribute("sname", sname);         
                
                response.sendRedirect("home1.jsp");                
            }else{
                response.sendRedirect("login.jsp");               
            }
        } catch (Exception e){}
    }
}
