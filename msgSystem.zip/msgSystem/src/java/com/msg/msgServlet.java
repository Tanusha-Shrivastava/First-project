
package com.msg;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class msgServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
        HttpSession session=request.getSession();
        String sname=session.getAttribute("sname").toString();
        String rname=session.getAttribute("rname").toString();
        String msg=request.getParameter("msg");       
        
        try{
            MsgDao obj = new MsgDao();
            obj.sendMsg(sname,rname,msg);
                      
            MsgDao obj1=new MsgDao();
            String fullmsg=obj1.getMsg(sname,rname);
            session.setAttribute("fullmsg",fullmsg);
            
            response.sendRedirect("chatWindow.jsp");                       
        }catch(Exception e){}
    }

}
