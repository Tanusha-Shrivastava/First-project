
package com.msg;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class msgServlet1 extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
         
        String rname=request.getParameter("rname");
        
        HttpSession session=request.getSession();
        session.setAttribute("rname", rname);
        String sname=session.getAttribute("sname").toString();
        
        MsgDao obj1=new MsgDao();
        String fullmsg;
        try {
            fullmsg = obj1.getMsg(sname,rname);
            session.setAttribute("fullmsg",fullmsg);
        } catch (Exception ex) {}
        
        
        response.sendRedirect("chatWindow.jsp");
    }

}
