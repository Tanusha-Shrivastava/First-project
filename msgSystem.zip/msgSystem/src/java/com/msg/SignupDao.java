
package com.msg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SignupDao {
    
    public SignupDao(){}
    String query="insert into login_info values(?,?)";
    String query1="select * from login_info where name=?";
    
    public boolean putValue(String sname,String pass) throws ClassNotFoundException, SQLException{
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/msg","root","s6h5i4v3a2m1");
        PreparedStatement ps=con.prepareStatement(query1);
        ps.setString(1,sname);        
           
        ResultSet rs=ps.executeQuery();
        if(rs.next()){return false;}
        else{
            PreparedStatement ps1=con.prepareStatement(query);
            ps1.setString(1,sname); 
            ps1.setString(2,pass);
            
            int count=ps1.executeUpdate();
            
            if(count!=0){return true;}
            return false;
        }
        
    }
}
